<?php

namespace Mpdf\Tag;

class Big extends InlineTag
{


}
